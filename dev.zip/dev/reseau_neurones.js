//2 couches
//12 neurones
//6 de sortie