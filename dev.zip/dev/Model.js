import { Tile } from './Tile.js';

export class Model {
    static GRAVITY    = 20;
    static JUMP_FORCE = 500;
    static SPEED      = 200;

    constructor() {
        this._direction = 0;
        this._gravitySpeed = 0;
        this._position = {x: 100, y:0};

        this.likheight = 124 / 2;
        this.likwidth = 120 / 2;

        this.max_tile = 20;
    }

    get position() { return this._position; }

    get lik_height() { return this.likheight; }
    get lik_whidth() { return this.likwidth; }

    get All_Tiles() { return this.AllTiles;}

    get direction() { return this._direction; }
    set direction(value) { return this._direction = value; }

    BindDisplay(callback) {this.b_Display = callback;}
    BindCanvaSize(callback) {this.b_canvaSize = callback;}

    Move(fps) {
        this._gravitySpeed += Model.GRAVITY;
        this._position.y += this._gravitySpeed / fps;
        this._position.x += this._direction * Model.SPEED / fps;
        let doodleCenter = this.getDoodleCenter();

        if(this._gravitySpeed > 0) {//en descente.
            this.AllTiles.forEach((tile) => {

                if(tile.touche(doodleCenter[0], doodleCenter[1])) {
                    this._Jump();
                }
            });
        }



        this.b_Display(this._position);
    }

    _Jump() {
        this._gravitySpeed = -Model.JUMP_FORCE;
    }

    getDoodleCenter() {
        return [this._position.x + (this.likwidth / 2), this._position.y + this.likheight];
    }

    createTiles() {
        this.AllTiles = [];
        let tile_max_range = this.b_canvaSize()[1] / 4;

        let lastY = 400;

        for (let i = 0; i < this.max_tile; i++) {
            let randType = parseInt(Math.random() * 3);
            let randX = parseInt(Math.random() * this.b_canvaSize()[0]);
            let randY = lastY - parseInt(Math.random() * tile_max_range);

            this.AllTiles.push(new Tile(randType, randX, randY));
            lastY = randY;
        }
    }
}