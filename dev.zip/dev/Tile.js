export class Tile {
    constructor(type, x, y) {

        this.type = type;
        if(this.type === 0) { this.tileY = 1; }
        else if(this.type === 1) {this.tileY = 19; }
        else if(this.type === 2) {this.tileY = 55; }

        this.x = x;
        this.y = y;

        this._widthCell   = 57; // Largeur d'une cellule en pixel.
        this._heightCell  = 17; // Hauteur d'une cellule en pixel.
    }
    setY(y) { this.y = y}

    dessiner(ctx, tiles) {
        ctx.drawImage(tiles, 1, this.tileY, this._widthCell, this._heightCell, this.x, this.y, this._widthCell, this._heightCell);
    }

    touche(x, y) {
        return x >= this.x && x <= this.x + this._widthCell && this.y === y;
    }
}