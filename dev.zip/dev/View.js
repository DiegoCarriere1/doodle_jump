import { Tile } from './Tile.js';


export class View {

    constructor(PNGs) {
        this._canvas = document.getElementById('id_canvas');
        this.ctx     = this._canvas.getContext('2d');
        this._hold_right = false;
        this._hold_left = false;

        this.background = PNGs[0];
        this.tiles = PNGs[3];
        this.lik_left = PNGs[1];
        this.lik_right = PNGs[2];

        this.Events();
    }

    Display(position) {

        this.ctx.clearRect(0, 0, this._canvas.width, this._canvas.height);
        this.ctx.drawImage(this.background, 0, 0, this._canvas.width, this._canvas.height);

        //plateformes
        this.b_GetTiles().forEach((tile) => {
            tile.dessiner(this.ctx, this.tiles);
        })



        //personnage
        if(position.x > this._canvas.width) {position.x = -29; }
        if(position.x < -30) {position.x = this._canvas.width; }

        let x = position.x;
        let y = position.y;

        if(this.b_GetDirection() !== 0){
            this.direction = this.b_GetDirection();
        }

        if(this.direction === 1) {
            this.ctx.drawImage(this.lik_right, x, y, this.b_GetLikWidth(), this.b_GetLikHeight());
        } else {
            this.ctx.drawImage(this.lik_left, x, y, this.b_GetLikWidth(), this.b_GetLikHeight());
        }
    }

    BindSetDirection(callback) {this.b_SetDirection = callback;}
    BindGetDirection(callback) {this.b_GetDirection = callback;}
    BindGetTiles(callback) {this.b_GetTiles = callback;}
    BindGetLikHeight(callback) {this.b_GetLikHeight = callback;}
    BindGetLikWidth(callback) {this.b_GetLikWidth = callback;}
    get CanvaSize() {return [this._canvas.width, this._canvas.height];}

    Events() {
        document.addEventListener('keydown', (evt) => {
            if (evt.key === 'ArrowLeft' || evt.key === 'ArrowRight') {
                switch (evt.key) {
                    case 'ArrowLeft': // Move left.
                        this._hold_left = true;
                        this.b_SetDirection(-1);
                        break;
                    case 'ArrowRight': // Move right.
                        this._hold_right = true;
                        this.b_SetDirection(1);
                        break;
                }
            }
        });

        document.addEventListener('keyup', (evt) => {
            switch (evt.key) {
                case 'ArrowLeft': // Move left.
                    if (!this._hold_right) {
                        this.b_SetDirection(0);
                    }
                    this._hold_left = false;
                    break;
                case 'ArrowRight': // Move right.
                    if (!this._hold_left) {
                        this.b_SetDirection(0);
                    }
                    this._hold_right = false;
                    break;
            }
        });
    }

}