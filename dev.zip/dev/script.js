import { Controller } from './Controller.js';


const background = new Image();
const lik_left = new Image();
const lik_right = new Image();
const tiles = new Image();

let PNGs = [background, lik_left, lik_right, tiles];

background.src = '../tiles/bck@2x.png';
lik_left.src = '../tiles/lik-left@2x.png';
lik_right.src = '../tiles/lik-right@2x.png';
tiles.src = '../tiles/game-tiles.png';

Promise.all([
    new Promise( (resolve) => {background.addEventListener('load', () => { resolve();}); }),
    new Promise( (resolve) => {lik_right.addEventListener('load', () => { resolve();}); }),
    new Promise( (resolve) => {lik_left.addEventListener('load', () => { resolve();}); }),
    new Promise( (resolve) => {tiles.addEventListener('load', () => { resolve();}); })
])
    .then(() => {
        const app = new Controller(PNGs);
        app.Update();
    });


